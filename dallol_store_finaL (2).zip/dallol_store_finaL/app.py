import os
import psycopg2
from psycopg2.extras import RealDictCursor
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from functools import wraps

load_dotenv()

app = Flask(__name__)
application = app
app.secret_key = 'your_secret_key_here'

UPLOAD_FOLDER = 'static/images'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# PostgreSQL config from .env
DB_HOST = os.getenv('DATABASE_HOST')
DB_PORT = os.getenv('DATABASE_PORT')
DB_NAME = os.getenv('DATABASE_NAME')
DB_USER = os.getenv('DATABASE_USER')
DB_PASSWORD = os.getenv('DATABASE_PASSWORD')

def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            image TEXT NOT NULL
        );
    ''')
    cur.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        message TEXT NOT NULL
    );
''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            items TEXT NOT NULL
        );
    
    ''')
    conn.commit()
    cur.close()
    conn.close()

init_db()

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'password'

@app.route('/')
def index():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT * FROM products;')
    products = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('index.html', products=products)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    product_id = request.form.get('product_id')
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT id, name, price FROM products WHERE id = %s;', (product_id,))
    product = cur.fetchone()
    cur.close()
    conn.close()

    if product:
        cart = session.get('cart', [])
        cart.append({'id': product['id'], 'name': product['name'], 'price': product['price']})
        session['cart'] = cart
        flash(f"Added {product['name']} to cart.")
    else:
        flash("Product not found.", "error")
    return redirect(url_for('index'))

@app.route('/cart')
def cart():
    cart = session.get('cart', [])
    return render_template('cart.html', cart=cart)

@app.route('/checkout', methods=['POST'])
def checkout():
    name = request.form.get('name')
    phone = request.form.get('phone')
    cart = session.get('cart', [])

    if not cart:
        flash("Your cart is empty.", "error")
        return redirect(url_for('cart'))

    if not name or not phone:
        flash("Please provide name and phone number.", "error")
        return redirect(url_for('cart'))

    items_str = ', '.join([item['name'] for item in cart])
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO orders (name, phone, items) VALUES (%s, %s, %s);', (name, phone, items_str))
    conn.commit()
    cur.close()
    conn.close()

    session.pop('cart', None)
    flash("Order placed successfully!")
    return redirect(url_for('index'))

 
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Invalid credentials", "error")
            return redirect(url_for('admin_login'))

    return render_template('admin_login.html')

def admin_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin/dashboard')
@admin_login_required
def admin_dashboard():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT * FROM orders;')
    orders = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('admin_dashboard.html', orders=orders)

@app.route('/admin/add_product', methods=['GET', 'POST'])
@admin_login_required
def admin_add_product():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)

    if request.method == 'POST':
        name = request.form.get('name')
        price = request.form.get('price')
        image = request.files.get('image')

        if not name or not price or not image:
            flash("Please provide all fields", "error")
            return redirect(url_for('admin_add_product'))

        filename = secure_filename(image.filename)
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        image.save(image_path)

        cur.execute('INSERT INTO products (name, price, image) VALUES (%s, %s, %s);', (name, price, filename))
        conn.commit()
        flash("Product added successfully!")

    cur.execute('SELECT * FROM products;')
    products = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('admin_add_product.html', products=products)

@app.route('/admin/edit/<int:product_id>', methods=['GET', 'POST'])
@admin_login_required
def admin_edit_product(product_id):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT * FROM products WHERE id = %s;', (product_id,))
    product = cur.fetchone()

    if not product:
        flash("Product not found.", "error")
        cur.close()
        conn.close()
        return redirect(url_for('admin_add_product'))

    if request.method == 'POST':
        name = request.form.get('name')
        price = request.form.get('price')
        image = request.files.get('image')

        filename = product['image']
        if image and image.filename:
            filename = secure_filename(image.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image.save(image_path)

        cur.execute('UPDATE products SET name = %s, price = %s, image = %s WHERE id = %s;',
                    (name, price, filename, product_id))
        conn.commit()
        flash("Product updated successfully!")
        cur.close()
        conn.close()
        return redirect(url_for('admin_add_product'))

    cur.close()
    conn.close()
    return render_template('admin_edit_product.html', product=product)

@app.route('/admin/delete/<int:product_id>')
@admin_login_required
def admin_delete_product(product_id):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT image FROM products WHERE id = %s;', (product_id,))
    product = cur.fetchone()

    if product:
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], product['image'])
        if os.path.exists(image_path):
            os.remove(image_path)
        cur.execute('DELETE FROM products WHERE id = %s;', (product_id,))
        conn.commit()
        flash("Product deleted.")
    else:
        flash("Product not found.", "error")

    cur.close()
    conn.close()
    return redirect(url_for('admin_add_product'))

@app.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('admin_login'))
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        phone = request.form.get('phone')
        message = request.form.get('message')

        if not name or not phone or not message:
            flash("Please fill out all fields.", "error")
            return redirect(url_for('contact'))

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO messages (name, phone, message) VALUES (%s, %s, %s);',
                    (name, phone, message))
        conn.commit()
        cur.close()
        conn.close()

        flash("Your message has been sent! Thank you.")
        return redirect(url_for('contact'))

    return render_template('contact.html')
@app.route('/admin/messages')
@admin_login_required
def admin_messages():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM messages ORDER BY id DESC;')
    messages = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('admin_messages.html', messages=messages)
@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
